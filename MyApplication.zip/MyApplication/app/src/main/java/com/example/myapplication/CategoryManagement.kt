package com.example.myapplication

import android.content.Intent
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class CategoryManagementActivity : AppCompatActivity() {
    private lateinit var dbHelper: DatabaseHelper
    private lateinit var categoryListView: ListView
    private lateinit var categoryInput: EditText
    private var selectedCategory: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_category_management)

        dbHelper = DatabaseHelper(this)
        categoryListView = findViewById(R.id.categoryList)
        categoryInput = findViewById(R.id.categoryInput)

        val addButton = findViewById<Button>(R.id.addCategoryButton)
        val editButton = findViewById<Button>(R.id.editCategoryButton)
        val deleteButton = findViewById<Button>(R.id.deleteCategoryButton)
        val backButton = findViewById<Button>(R.id.backButton)

        loadCategories()

        categoryListView.setOnItemClickListener { _, _, position, _ ->
            selectedCategory = categoryListView.adapter.getItem(position).toString()
            categoryInput.setText(selectedCategory)
        }

        addButton.setOnClickListener { addCategory() }
        editButton.setOnClickListener { editCategory() }
        deleteButton.setOnClickListener { deleteCategory() }

        // ✅ Navigate back to DashboardActivity or previous page
        backButton.setOnClickListener {
            val intent = Intent(this, DashboardActivity::class.java)
            startActivity(intent)
            finish()
        }
    }

    private fun loadCategories() {
        val categories = dbHelper.getCategories()
        val adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, categories)
        categoryListView.adapter = adapter
    }

    private fun addCategory() {
        val categoryName = categoryInput.text.toString().trim()
        if (categoryName.isNotEmpty()) {
            val isInserted = dbHelper.addCategory(categoryName)
            if (isInserted) {
                Toast.makeText(this, "Category Added!", Toast.LENGTH_SHORT).show()
                loadCategories()
                categoryInput.text.clear()
            } else {
                Toast.makeText(this, "Failed to add category!", Toast.LENGTH_SHORT).show()
            }
        } else {
            Toast.makeText(this, "Enter a category name!", Toast.LENGTH_SHORT).show()
        }
    }

    private fun editCategory() {
        val newCategoryName = categoryInput.text.toString().trim()
        if (!selectedCategory.isNullOrEmpty() && newCategoryName.isNotEmpty()) {
            val isUpdated = dbHelper.updateCategory(selectedCategory!!, newCategoryName)
            if (isUpdated) {
                Toast.makeText(this, "Category Updated!", Toast.LENGTH_SHORT).show()
                loadCategories()
            } else {
                Toast.makeText(this, "Failed to update category!", Toast.LENGTH_SHORT).show()
            }
        } else {
            Toast.makeText(this, "Select and enter a new name!", Toast.LENGTH_SHORT).show()
        }
    }

    private fun deleteCategory() {
        if (!selectedCategory.isNullOrEmpty()) {
            val isDeleted = dbHelper.deleteCategory(selectedCategory!!)
            if (isDeleted) {
                Toast.makeText(this, "Category Deleted!", Toast.LENGTH_SHORT).show()
                loadCategories()
                categoryInput.text.clear()
                selectedCategory = null
            } else {
                Toast.makeText(this, "Failed to delete category!", Toast.LENGTH_SHORT).show()
            }
        } else {
            Toast.makeText(this, "Select a category to delete!", Toast.LENGTH_SHORT).show()
        }
    }
}
