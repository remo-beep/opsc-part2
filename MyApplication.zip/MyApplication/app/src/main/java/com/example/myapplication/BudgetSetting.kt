package com.example.myapplication

import android.app.DatePickerDialog
import android.content.Intent
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import java.text.SimpleDateFormat
import java.util.*

class BudgetSettingActivity : AppCompatActivity() {
    private lateinit var dbHelper: DatabaseHelper
    private lateinit var budgetInput: EditText
    private lateinit var categorySpinner: Spinner
    private lateinit var dateText: TextView
    private var selectedDate: String = "Not set"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_budget_setting)

        dbHelper = DatabaseHelper(this)
        budgetInput = findViewById(R.id.budgetInput)
        categorySpinner = findViewById(R.id.categorySpinner)
        dateText = findViewById(R.id.dateText)

        val selectMonthButton = findViewById<Button>(R.id.selectMonthButton)
        val setBudgetButton = findViewById<Button>(R.id.setBudgetButton)
        val viewBudgetsButton = findViewById<Button>(R.id.viewBudgetsButton)
        val viewCategoriesButton = findViewById<Button>(R.id.viewCategoriesButton)
        val backButton = findViewById<Button>(R.id.backButton)

        loadCategories()

        selectMonthButton.setOnClickListener { pickMonth() }
        setBudgetButton.setOnClickListener { saveBudget() }
        viewBudgetsButton.setOnClickListener { navigateToViewBudgets() }
        viewCategoriesButton.setOnClickListener {
            val intent = Intent(this, CategoryManagementActivity::class.java)
            startActivity(intent)
        }
        backButton.setOnClickListener { finish() } // Returns to previous activity
    }

    private fun loadCategories() {
        val categories = dbHelper.getCategories()
        val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, categories)
        categorySpinner.adapter = adapter
    }

    private fun pickMonth() {
        val calendar = Calendar.getInstance()
        val datePicker = DatePickerDialog(this, { _, year, month, _ ->
            selectedDate = "$year-${month + 1}" // Convert to YYYY-MM format
            dateText.text = "Selected Month: $selectedDate"
        }, calendar.get(Calendar.YEAR), calendar.get(Calendar.MONTH), calendar.get(Calendar.DAY_OF_MONTH))

        datePicker.show()
    }

    private fun saveBudget() {
        val budgetAmount = budgetInput.text.toString().trim()
        val category = categorySpinner.selectedItem.toString()

        if (budgetAmount.isNotEmpty() && selectedDate != "Not set") {
            val budgetValue = budgetAmount.toDoubleOrNull()
            if (budgetValue != null) {
                dbHelper.saveBudget(budgetValue, category, selectedDate)
                Toast.makeText(this, "Budget Set Successfully!", Toast.LENGTH_SHORT).show()
                budgetInput.text.clear()
                dateText.text = "Selected Month: Not set"
            } else {
                Toast.makeText(this, "Enter a valid budget amount!", Toast.LENGTH_SHORT).show()
            }
        } else {
            Toast.makeText(this, "Please enter a budget amount and select a month!", Toast.LENGTH_SHORT).show()
        }
    }

    private fun navigateToViewBudgets() {
        val budgets = dbHelper.getBudgets() // Retrieve inserted budgets from the database
        val intent = Intent(this, ViewBudgetsActivity::class.java)
        intent.putStringArrayListExtra("budgets", ArrayList(budgets)) // Pass budgets to next activity
        startActivity(intent)
    }
}
