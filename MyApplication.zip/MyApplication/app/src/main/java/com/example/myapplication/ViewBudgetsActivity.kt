package com.example.myapplication

import android.content.Intent
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class ViewBudgetsActivity : AppCompatActivity() {
    private lateinit var dbHelper: DatabaseHelper
    private lateinit var budgetListView: ListView
    private var selectedBudget: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_view_budgets)

        dbHelper = DatabaseHelper(this)
        budgetListView = findViewById(R.id.budgetListView)
        val backButton = findViewById<Button>(R.id.backButton)
        val editButton = findViewById<Button>(R.id.editButton)
        val deleteButton = findViewById<Button>(R.id.deleteButton)

        loadBudgets()

        budgetListView.setOnItemClickListener { _, _, position, _ ->
            selectedBudget = budgetListView.adapter.getItem(position).toString()
        }

        editButton.setOnClickListener { editBudget() }
        deleteButton.setOnClickListener { deleteBudget() }
        backButton.setOnClickListener { navigateBack() }
    }

    private fun loadBudgets() {
        val budgets = dbHelper.getBudgets()

        if (budgets.isNotEmpty()) {
            val adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, budgets) // Corrected ListAdapter format
            budgetListView.adapter = adapter
        } else {
            Toast.makeText(this, "No budgets found!", Toast.LENGTH_SHORT).show()
        }
    }

    private fun editBudget() {
        if (!selectedBudget.isNullOrEmpty()) {
            Toast.makeText(this, "Editing: $selectedBudget (Implement edit logic)", Toast.LENGTH_SHORT).show()
            // TODO: Implement actual edit functionality
        } else {
            Toast.makeText(this, "Select a budget to edit!", Toast.LENGTH_SHORT).show()
        }
    }

    private fun deleteBudget() {
        if (!selectedBudget.isNullOrEmpty()) {
            val budgetDetails = selectedBudget!!.split(", ") // Splitting budget string into components
            if (budgetDetails.size >= 3) {
                val amount = budgetDetails[0].replace("Amount: ", "").toDoubleOrNull()
                val category = budgetDetails[1].replace("Category: ", "")
                val month = budgetDetails[2].replace("Month: ", "")

                if (amount != null) {
                    val isDeleted = dbHelper.deleteBudget(amount, category, month)
                    if (isDeleted) {
                        Toast.makeText(this, "Budget Deleted!", Toast.LENGTH_SHORT).show()
                        loadBudgets()
                    } else {
                        Toast.makeText(this, "Failed to delete budget!", Toast.LENGTH_SHORT).show()
                    }
                } else {
                    Toast.makeText(this, "Invalid budget selection!", Toast.LENGTH_SHORT).show()
                }
            } else {
                Toast.makeText(this, "Budget format error!", Toast.LENGTH_SHORT).show()
            }
        } else {
            Toast.makeText(this, "Select a budget to delete!", Toast.LENGTH_SHORT).show()
        }
    }

    private fun navigateBack() {
        val intent = Intent(this, DashboardActivity::class.java)
        startActivity(intent)
        finish()
    }
}
