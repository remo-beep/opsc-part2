package com.example.myapplication

import android.content.ContentValues
import android.content.Context
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

class DatabaseHelper(context: Context) : SQLiteOpenHelper(context, DATABASE_NAME, null, DATABASE_VERSION) {

    companion object {
        private const val DATABASE_NAME = "ExpenseMaster.db"
        private const val DATABASE_VERSION = 1

        // User Table
        private const val TABLE_USERS = "users"
        private const val COLUMN_USER_ID = "id"
        private const val COLUMN_USERNAME = "username"
        private const val COLUMN_PASSWORD = "password"

        // Categories Table
        private const val TABLE_CATEGORIES = "categories"
        private const val COLUMN_CATEGORY_ID = "category_id"
        private const val COLUMN_CATEGORY_NAME = "name"

        // Expenses Table
        private const val TABLE_EXPENSES = "expenses"
        private const val COLUMN_EXPENSE_ID = "expense_id"
        private const val COLUMN_AMOUNT = "amount"
        private const val COLUMN_DESCRIPTION = "description"
        private const val COLUMN_CATEGORY = "category"
        private const val COLUMN_DATE = "date"
    }

    override fun onCreate(db: SQLiteDatabase) {
        val createUserTable =
            "CREATE TABLE $TABLE_USERS ($COLUMN_USER_ID INTEGER PRIMARY KEY AUTOINCREMENT, " +
                    "$COLUMN_USERNAME TEXT UNIQUE, $COLUMN_PASSWORD TEXT)"

        val createCategoryTable =
            "CREATE TABLE $TABLE_CATEGORIES ($COLUMN_CATEGORY_ID INTEGER PRIMARY KEY AUTOINCREMENT, " +
                    "$COLUMN_CATEGORY_NAME TEXT UNIQUE)"

        val createExpenseTable =
            "CREATE TABLE $TABLE_EXPENSES ($COLUMN_EXPENSE_ID INTEGER PRIMARY KEY AUTOINCREMENT, " +
                    "$COLUMN_AMOUNT REAL, $COLUMN_DESCRIPTION TEXT, $COLUMN_CATEGORY TEXT, $COLUMN_DATE TEXT)"

        db.execSQL(createUserTable)
        db.execSQL(createCategoryTable)
        db.execSQL(createExpenseTable)
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        db.execSQL("DROP TABLE IF EXISTS $TABLE_USERS")
        db.execSQL("DROP TABLE IF EXISTS $TABLE_CATEGORIES")
        db.execSQL("DROP TABLE IF EXISTS $TABLE_EXPENSES")
        onCreate(db)
    }

    // ✅ User Authentication (Register & Login)
    fun insertUser(username: String, password: String): Boolean {
        val db = writableDatabase
        val values = ContentValues().apply {
            put(COLUMN_USERNAME, username)
            put(COLUMN_PASSWORD, password)
        }
        val result = db.insert(TABLE_USERS, null, values)
        db.close()
        return result != -1L
    }

    fun checkUser(username: String, password: String): Boolean {
        val db = readableDatabase
        val query = "SELECT * FROM $TABLE_USERS WHERE $COLUMN_USERNAME = ? AND $COLUMN_PASSWORD = ?"
        val cursor = db.rawQuery(query, arrayOf(username, password))
        val exists = cursor.count > 0
        cursor.close()
        db.close()
        return exists
    }

    // ✅ Category Management
    fun addCategory(name: String): Boolean {
        val db = writableDatabase
        val values = ContentValues().apply { put(COLUMN_CATEGORY_NAME, name) }
        val result = db.insert(TABLE_CATEGORIES, null, values)
        db.close()
        return result != -1L
    }

    fun updateCategory(categoryName: String, newName: String): Boolean {
        val db = writableDatabase
        val values = ContentValues().apply { put(COLUMN_CATEGORY_NAME, newName) }
        val result =
            db.update(TABLE_CATEGORIES, values, "$COLUMN_CATEGORY_NAME=?", arrayOf(categoryName))
        db.close()
        return result > 0
    }

    fun deleteCategory(categoryName: String): Boolean {
        val db = writableDatabase
        val result = db.delete(TABLE_CATEGORIES, "$COLUMN_CATEGORY_NAME=?", arrayOf(categoryName))
        db.close()
        return result > 0
    }

    fun getCategories(): List<String> {
        val categories = mutableListOf<String>()
        val db = readableDatabase
        val cursor: Cursor =
            db.rawQuery("SELECT $COLUMN_CATEGORY_NAME FROM $TABLE_CATEGORIES", null)
        if (cursor.moveToFirst()) {
            do {
                categories.add(cursor.getString(0))
            } while (cursor.moveToNext())
        }
        cursor.close()
        db.close()
        return categories
    }

    // ✅ Expense Management
    fun addExpense(amount: Double, description: String, category: String, date: String): Boolean {
        val db = writableDatabase
        val values = ContentValues().apply {
            put(COLUMN_AMOUNT, amount)
            put(COLUMN_DESCRIPTION, description)
            put(COLUMN_CATEGORY, category)
            put(COLUMN_DATE, date)
        }
        val result = db.insert(TABLE_EXPENSES, null, values)
        db.close()
        return result != -1L
    }

    fun updateExpense(
        expenseId: Int,
        amount: Double,
        description: String,
        category: String,
        date: String
    ): Boolean {
        val db = writableDatabase
        val values = ContentValues().apply {
            put(COLUMN_AMOUNT, amount)
            put(COLUMN_DESCRIPTION, description)
            put(COLUMN_CATEGORY, category)
            put(COLUMN_DATE, date)
        }
        val result =
            db.update(TABLE_EXPENSES, values, "$COLUMN_EXPENSE_ID=?", arrayOf(expenseId.toString()))
        db.close()
        return result > 0
    }

    fun deleteExpense(expenseId: Int): Boolean {
        val db = writableDatabase
        val result =
            db.delete(TABLE_EXPENSES, "$COLUMN_EXPENSE_ID=?", arrayOf(expenseId.toString()))
        db.close()
        return result > 0
    }

    fun saveBudget(amount: Double, category: String, month: String): Boolean {
        val db = writableDatabase
        val values = ContentValues().apply {
            put("amount", amount)
            put("category", category)
            put("month", month)
        }
        val result = db.insert("budgets", null, values)
        db.close()
        return result != -1L
    }



    fun getBudgets(): List<String> {
        val budgets = mutableListOf<String>()
        val db = readableDatabase
        val cursor = db.rawQuery("SELECT amount, category, month FROM budgets", null)

        if (cursor.moveToFirst()) {
            do {
                val budget =
                    "Amount: ${cursor.getDouble(0)}, Category: ${cursor.getString(1)}, Month: ${
                        cursor.getString(2)
                    }"
                budgets.add(budget)
            } while (cursor.moveToNext())
        }
        cursor.close()
        db.close()
        return budgets
    }
    fun deleteBudget(amount: Double, category: String, month: String): Boolean {
        val db = writableDatabase
        val result = db.delete(
            "budgets",
            "amount=? AND category=? AND month=?",
            arrayOf(amount.toString(), category, month)
        )
        db.close()
        return result > 0
    }
    fun getExpenses(): List<String> {
        val expenses = mutableListOf<String>()
        val db = readableDatabase
        val cursor = db.rawQuery("SELECT amount, description, category, date FROM expenses", null)

        if (cursor.moveToFirst()) {
            do {
                val expense = "Amount: ${cursor.getDouble(0)}, Description: ${cursor.getString(1)}, Category: ${cursor.getString(2)}, Date: ${cursor.getString(3)}"
                expenses.add(expense)
            } while (cursor.moveToNext())
        }
        cursor.close()
        db.close()
        return expenses
    }

    fun getFilteredExpenses(startDate: String, endDate: String): List<String> {
        val expenses = mutableListOf<String>()
        val db = readableDatabase
        val cursor = db.rawQuery("SELECT amount, description, category, date FROM expenses WHERE date BETWEEN ? AND ?", arrayOf(startDate, endDate))

        if (cursor.moveToFirst()) {
            do {
                val expense = "**Amount: ${cursor.getDouble(0)}, Description: ${cursor.getString(1)}, Category: ${cursor.getString(2)}, Date: ${cursor.getString(3)}**"
                expenses.add(expense)
            } while (cursor.moveToNext())
        }
        cursor.close()
        db.close()
        return expenses
    }

}


