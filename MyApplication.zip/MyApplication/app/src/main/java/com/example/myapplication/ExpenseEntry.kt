package com.example.myapplication

import android.app.DatePickerDialog
import android.content.Intent
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import java.text.SimpleDateFormat
import java.util.*

class ExpenseEntryActivity : AppCompatActivity() {
    private lateinit var dbHelper: DatabaseHelper
    private lateinit var amountInput: EditText
    private lateinit var descriptionInput: EditText
    private lateinit var categorySpinner: Spinner
    private lateinit var startDateInput: EditText
    private lateinit var endDateInput: EditText
    private lateinit var addExpenseButton: Button
    private lateinit var trackExpenseButton: Button
    private lateinit var backButton: Button
    private var selectedStartDate: String? = null
    private var selectedEndDate: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_expense_entry)

        dbHelper = DatabaseHelper(this)

        amountInput = findViewById(R.id.amountInput)
        descriptionInput = findViewById(R.id.descriptionInput)
        categorySpinner = findViewById(R.id.categorySpinner)
        startDateInput = findViewById(R.id.startDateInput)
        endDateInput = findViewById(R.id.endDateInput)
        addExpenseButton = findViewById(R.id.saveExpenseButton)
        trackExpenseButton = findViewById(R.id.trackExpensesButton)
        backButton = findViewById(R.id.backButton)

        loadCategories()

        startDateInput.setOnClickListener { pickStartDate() }
        endDateInput.setOnClickListener { pickEndDate() }

        addExpenseButton.setOnClickListener { addExpense() }
        trackExpenseButton.setOnClickListener { navigateToExpenseList() }
        backButton.setOnClickListener { finish() }
    }

    private fun loadCategories() {
        val categories = dbHelper.getCategories()
        val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, categories)
        categorySpinner.adapter = adapter
    }

    private fun pickStartDate() {
        val calendar = Calendar.getInstance()
        val datePicker = DatePickerDialog(this, { _, year, month, dayOfMonth ->
            selectedStartDate = "$year-${month + 1}-$dayOfMonth"
            startDateInput.setText(selectedStartDate)
        }, calendar.get(Calendar.YEAR), calendar.get(Calendar.MONTH), calendar.get(Calendar.DAY_OF_MONTH))
        datePicker.show()
    }

    private fun pickEndDate() {
        val calendar = Calendar.getInstance()
        val datePicker = DatePickerDialog(this, { _, year, month, dayOfMonth ->
            selectedEndDate = "$year-${month + 1}-$dayOfMonth"
            endDateInput.setText(selectedEndDate)
        }, calendar.get(Calendar.YEAR), calendar.get(Calendar.MONTH), calendar.get(Calendar.DAY_OF_MONTH))
        datePicker.show()
    }

    private fun addExpense() {
        val amount = amountInput.text.toString().trim()
        val description = descriptionInput.text.toString().trim()
        val category = categorySpinner.selectedItem.toString()

        if (amount.isNotEmpty() && description.isNotEmpty() && selectedStartDate != null && selectedEndDate != null) {
            val amountValue = amount.toDoubleOrNull()
            if (amountValue != null) {
                val isInserted = dbHelper.addExpense(amountValue, description, category, selectedStartDate!!)
                if (isInserted) {
                    Toast.makeText(this, "Expense Saved!", Toast.LENGTH_SHORT).show()
                    amountInput.text.clear()
                    descriptionInput.text.clear()
                    startDateInput.text.clear()
                    endDateInput.text.clear()
                } else {
                    Toast.makeText(this, "Failed to save expense!", Toast.LENGTH_SHORT).show()
                }
            } else {
                Toast.makeText(this, "Enter a valid amount!", Toast.LENGTH_SHORT).show()
            }
        } else {
            Toast.makeText(this, "Please fill all fields, including start and end date!", Toast.LENGTH_SHORT).show()
        }
    }

    private fun navigateToExpenseList() {
        val expenses = dbHelper.getExpenses()
        val intent = Intent(this, ExpenseListActivity::class.java)
        intent.putStringArrayListExtra("expenses", ArrayList(expenses))
        startActivity(intent)
    }
}
