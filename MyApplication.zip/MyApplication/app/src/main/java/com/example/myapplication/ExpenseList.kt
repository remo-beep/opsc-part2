package com.example.myapplication

import android.app.DatePickerDialog
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import java.text.SimpleDateFormat
import java.util.*

class ExpenseListActivity : AppCompatActivity() {
    private lateinit var dbHelper: DatabaseHelper
    private lateinit var expenseListView: ListView
    private lateinit var startDateInput: EditText
    private lateinit var endDateInput: EditText
    private lateinit var filterButton: Button
    private var selectedStartDate: String? = null
    private var selectedEndDate: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_expense_list)

        dbHelper = DatabaseHelper(this)
        expenseListView = findViewById(R.id.expenseListView)
        startDateInput = findViewById(R.id.startDateInput)
        endDateInput = findViewById(R.id.endDateInput)
        filterButton = findViewById(R.id.filterButton)
        val backButton = findViewById<Button>(R.id.backButton)

        startDateInput.setOnClickListener { pickStartDate() }
        endDateInput.setOnClickListener { pickEndDate() }
        filterButton.setOnClickListener { filterExpenses() }

        loadExpenses()

        backButton.setOnClickListener { finish() } // Return to previous page
    }

    private fun pickStartDate() {
        val calendar = Calendar.getInstance()
        val datePicker = DatePickerDialog(this, { _, year, month, dayOfMonth ->
            selectedStartDate = "$year-${month + 1}-$dayOfMonth"
            startDateInput.setText(selectedStartDate)
        }, calendar.get(Calendar.YEAR), calendar.get(Calendar.MONTH), calendar.get(Calendar.DAY_OF_MONTH))
        datePicker.show()
    }

    private fun pickEndDate() {
        val calendar = Calendar.getInstance()
        val datePicker = DatePickerDialog(this, { _, year, month, dayOfMonth ->
            selectedEndDate = "$year-${month + 1}-$dayOfMonth"
            endDateInput.setText(selectedEndDate)
        }, calendar.get(Calendar.YEAR), calendar.get(Calendar.MONTH), calendar.get(Calendar.DAY_OF_MONTH))
        datePicker.show()
    }

    private fun loadExpenses() {
        val expenses = dbHelper.getExpenses()

        if (expenses.isNotEmpty()) {
            val adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, expenses)
            expenseListView.adapter = adapter
        } else {
            Toast.makeText(this, "No expenses found!", Toast.LENGTH_SHORT).show()
        }
    }

    private fun filterExpenses() {
        if (selectedStartDate != null && selectedEndDate != null) {
            val filteredExpenses = dbHelper.getFilteredExpenses(selectedStartDate!!, selectedEndDate!!)
            if (filteredExpenses.isNotEmpty()) {
                val adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, filteredExpenses)
                expenseListView.adapter = adapter
                Toast.makeText(this, "Filtered Expenses Highlighted!", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(this, "No expenses found in this date range!", Toast.LENGTH_SHORT).show()
            }
        } else {
            Toast.makeText(this, "Please select both Start Date and End Date!", Toast.LENGTH_SHORT).show()
        }
    }
}
