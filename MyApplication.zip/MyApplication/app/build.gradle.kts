// App-level build.gradle.kts

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.example.myapplication"  // The unique identifier for your app
    compileSdk = 35  // Target the latest SDK version

    defaultConfig {
        applicationId = "com.example.myapplication"  // Package name for your app
        minSdk = 24  // Minimum SDK version
        targetSdk = 34  // Target SDK version
        versionCode = 1  // Version code for your app
        versionName = "1.0"  // Version name for your app

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"  // For testing
    }

    buildTypes {
        getByName("release") {
            isMinifyEnabled = false  // Set to true if you want ProGuard enabled
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"  // Add your custom ProGuard rules here
            )
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_1_8  // Ensure Java 8 compatibility
        targetCompatibility = JavaVersion.VERSION_1_8
    }

    kotlinOptions {
        jvmTarget = "1.8"  // Kotlin JVM target version
    }
}

dependencies {
    implementation("androidx.appcompat:appcompat:1.7.0")  // AppCompat for backwards compatibility
    implementation("androidx.core:core-ktx:1.15.0")  // Core Kotlin extensions
    implementation("com.google.android.material:material:1.12.0")  // Material Design components
    implementation("androidx.constraintlayout:constraintlayout:2.2.1")  // ConstraintLayout for UI
    testImplementation("junit:junit:4.13.2")  // JUnit for unit testing
    androidTestImplementation("androidx.test.ext:junit:1.2.1")  // JUnit for Android UI tests
    androidTestImplementation("androidx.test.espresso:espresso-core:3.6.1")  // Espresso for UI testing

    // BCrypt library for password hashing
    implementation("org.mindrot:jbcrypt:0.4")  // Add the BCrypt library for password hashing
}
